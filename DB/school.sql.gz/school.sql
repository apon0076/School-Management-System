-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2019 at 04:24 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `trnx_id` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `amount` int(50) NOT NULL,
  `trnx_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`trnx_id`, `user_id`, `purpose`, `status`, `amount`, `trnx_date`) VALUES
(1, '01', 'Academic Fee', 'Diposite', 100, '2019-04-08'),
(2, 'salman1', 'Salary', 'Cost', 10000, '2019-04-08'),
(3, 'arif1', 'Academic Fee', 'Diposite', 500, '2019-04-08'),
(4, 'salman1', 'Other Benefits', 'Cost', 5000, '2019-04-08'),
(5, 'arif1', 'Academic Fee', 'Diposite', 20000, '2019-04-09');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `phone` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `mail` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `phone`, `address`, `mail`, `image`) VALUES
('apon1', 'Apon', '01754170067', 'Uttara', 'apon@gmail.com', 'la110-55-2009-100532-high-jpg.jpg'),
('nibir1', 'Nibir', '123456', 'Uttara', 'nibir@gmail.com', ''),
('zoo1', 'Zubayer', '014745558455', 'Uttara', 'zoo1@school.edu', '52819597_585529761929490_7706524883672367104_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `atten_id` int(255) NOT NULL,
  `type_or_class` varchar(225) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `att_date` date NOT NULL,
  `in_time` time(6) NOT NULL,
  `out_time` time(6) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`atten_id`, `type_or_class`, `user_id`, `att_date`, `in_time`, `out_time`, `status`) VALUES
(1, '06', 'arif1', '2019-04-08', '00:00:00.000000', '00:00:00.000000', 'Absent'),
(2, '06', 'kamrul1', '2019-04-08', '00:00:00.000000', '00:00:00.000000', 'Absent'),
(3, '06', 'arif1', '2019-04-08', '00:00:00.000000', '00:00:00.000000', 'Present'),
(4, '06', 'kamrul1', '2019-04-08', '00:00:00.000000', '00:00:00.000000', 'Absent'),
(5, 'teacher', 'salman1', '2019-04-08', '02:03:16.000000', '11:58:02.000000', 'in-time'),
(6, '06', 'arif1', '2019-04-08', '00:00:00.000000', '00:00:00.000000', 'Present'),
(7, '06', 'kamrul1', '2019-04-08', '00:00:00.000000', '00:00:00.000000', 'Absent'),
(8, 's_manager', 'nobin1', '2019-04-08', '09:33:20.000000', '11:57:35.000000', 'Late'),
(9, 'a_manager', 'zulkar1', '2019-04-08', '09:39:36.000000', '11:44:17.000000', 'Late'),
(10, 'g_employee', 'hridoy1', '2019-04-08', '09:41:48.000000', '11:53:17.000000', 'Late'),
(11, 'g_employee', 'modon1', '2019-04-08', '11:46:34.000000', '11:51:34.000000', 'Late'),
(12, 's_manager', 'nobin1', '2019-04-09', '12:03:41.000000', '08:17:35.000000', 'Late'),
(13, 'a_manager', 'zulkar1', '2019-04-09', '12:04:46.000000', '08:19:24.000000', 'Late'),
(14, 'g_employee', 'modon1', '2019-04-09', '12:05:30.000000', '02:47:03.000000', 'Late'),
(15, 'teacher', 'salman1', '2019-04-09', '12:06:24.000000', '08:18:47.000000', 'Late'),
(16, '06', 'arif1', '2019-04-09', '00:00:00.000000', '00:00:00.000000', 'Absent'),
(17, '06', 'kamrul1', '2019-04-09', '00:00:00.000000', '00:00:00.000000', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `name`, `phone`, `address`, `mail`, `designation`, `image`, `status`) VALUES
('hridoy1', 'Hridoy', '01784599999', 'uttara', 'hridoy1@gmail.com', 'Clark', 'la110-55-2009-100532-high-jpg.jpg', 1),
('modon1', 'Modon', '01785474777', 'Uttara', 'modon@gmail.com', 'gg', 's-bazin.jpg', 1),
('mofiz1', 'Mofiz', '1478520369', 'Uttara', 'mofiz2gmail.com', 'Cashier', '22.jpg', 1),
('nobin1', 'Nobin', '0147852360', 'Kustia', 'nobin@gmail.com', 'Addmission Officer', 'images (1).jpg', 1),
('raju12', 'Raju', '178522149', 'Uttara', 'raju12@gmail.com', 'Assistant Student Manager', '52819597_585529761929490_7706524883672367104_n.jpg', 1),
('zulkar1', 'Zulkar Nain', '0178523690', 'Bamnar Tek', 'zulkar@school.edu', 'Accountant', 'images.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(10) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `pass` varchar(8) NOT NULL,
  `type` varchar(10) NOT NULL,
  `status` int(15) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `user_id`, `pass`, `type`, `status`) VALUES
(1, 'apon1', '1234', 'admin', 0),
(2, 'nibir1', '1234', 'admin', 0),
(3, 'nobin1', '1234', 's_manager', 1),
(5, 'salman1', '1234', 'teacher', 1),
(6, 'admin@school.edu', '12345', 'teacher', 0),
(7, 'admin@schadfool.edu', '12345', 'teacher', 0),
(8, 'admin@school.eduadf', '12345', 'g_employee', 0),
(9, 'zulkar1', '1234', 'a_manager', 1),
(10, 'modon1', '1234', 'g_employee', 1),
(14, 'zoo1', '1234', 'admin', 0),
(15, 'biplob1', '1234', 'teacher', 1),
(18, 'hridoy1', '1234', 'g_employee', 1),
(20, 'raju12', '1234', 's_manager', 1),
(22, 'mofiz1', '1234', 'a_manager', 1),
(24, 'gg', 'gjffytf', 'teacher', 0),
(29, 'Rasel123', '1234', 'student', 0),
(30, 'Rana123', '1234', 'student', 0),
(31, 'Sabikunnahar123', '1234', 'student', 0),
(32, 'Sanjida123', '1234', 'student', 0),
(33, 'Rahim123', '1234', 'student', 0),
(34, 'Sadman123', '1234', 'student', 0),
(35, 'Sadik123', '1234', 'student', 0),
(36, 'Razzak123', '1234', 'student', 0),
(37, 'Rakib123', '1234', 'student', 0),
(38, 'Ridoy123', '1234', 'student', 0),
(39, 'Asfaq123', '1234', 'student', 0),
(40, 'Sufian123', '1234', 'student', 0),
(41, 'Kader123', '1234', 'student', 0),
(42, 'Meskat123', '1234', 'student', 0),
(43, 'Anirban123', '1234', 'student', 0),
(44, 'Rakhi123', '1234', 'student', 0),
(45, 'Rafia123', '1234', 'student', 0),
(46, 'Nahin123', '1234', 'student', 0),
(47, 'Robi123', '1234', 'student', 0),
(48, 'Mafia123', '1234', 'student', 0),
(49, 'Rubi123', '1234', 'student', 0);

-- --------------------------------------------------------

--
-- Table structure for table `salary_info`
--

CREATE TABLE `salary_info` (
  `salary_id` int(50) NOT NULL,
  `designation` varchar(225) NOT NULL,
  `salary` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary_info`
--

INSERT INTO `salary_info` (`salary_id`, `designation`, `salary`) VALUES
(4, 'clark', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stu_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `stu_group` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `image` varchar(255) NOT NULL,
  `class` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stu_id`, `name`, `phone`, `address`, `stu_group`, `gender`, `image`, `class`) VALUES
('Anirban123', 'Anirban Ahmed', '01634550020', 'jashimuddin,dhaka', 'N/A', 'Male', 'peapack.jpg', 8),
('Asfaq123', 'Asfaq Ahmed', '01634550016', 'bashundhara,dhaka', 'N/A', 'Male', 'la110-55-2009-100532-high-jpg.jpg', 8),
('Kader123', 'Kader Ahmed', '01634550019', 'kuril,dhaka', 'N/A', 'Male', 'images.jpg', 8),
('Mafia123', 'Mafia Rahi', '01634550029', 'mirpur', 'N/A', 'Female', 'peapack.jpg', 9),
('Meskat123', 'Meskat Ahmed', '01717670955', 'bashundhara,dhaka', 'N/A', 'Male', 's-bazin.jpg', 8),
('Nahin123', 'Nhin Khan', '01634550026', 'dhanmondi,dhaka', 'N/A', 'Male', '220px-Euan_Sutherland_-_Chief_Executive,_The_Co-operative_Group.jpg', 9),
('Rafia123', 'Rafia Rahman', '01634550023', 'uttara,dhaka', 'Science', 'Female', 'images.jpg', 9),
('Rahim123', 'Rahim Haque', '01634550011', 'Nillkhet,dhaka', 'N/A', 'Male', '', 6),
('Rakhi123', 'Rakhi Rani', '01634550027', 'banani,dhaka', 'N/A', 'Male', 'peapack.jpg', 8),
('Rakib123', 'Rakib Khan', '01634550015', 'Ajompur,Dhaka', 'N/A', 'Male', 'images (1).jpg', 7),
('Rana123', 'Rana Ahmed ', '01717670944', 'khilkhet,dhaka', 'N/A', 'Male', '', 6),
('Rasel123', 'Rasel Ahmed', '01707123456', 'uttara,dhaka', 'N/A', 'Male', '', 6),
('Razzak123', 'Razzak Khan', '01634550024', 'banani,dhaka', 'N/A', 'Male', '220px-Euan_Sutherland_-_Chief_Executive,_The_Co-operative_Group.jpg', 7),
('Ridoy123', 'Ridoy Ahmed', '01634550016', 'Josimuddin,dhaka', 'N/A', 'Male', 'images.jpg', 7),
('Robi123', 'Robi Rahman', '01634550026', 'uttara,dhaka', 'Commerce', 'Male', 'la110-55-2009-100532-high-jpg.jpg', 9),
('Rubi123', 'Rubi Khan', '01634550030', 'uttara,dhaka', 'Arts', 'Female', 'images.jpg', 9),
('Sabikunnah', 'Sabikunnahar', '01634550002', 'mirpur,dhaka', 'N/A', 'Female', '', 6),
('Sadik123', 'Sadik Khan', '01634550013', 'Rajlokkhi,dhaka', 'N/A', 'Male', '', 7),
('Sadman123', 'Sadman Rahman', '01633455001', 'mohammadpur,dhaka', 'N/A', 'Male', '', 7),
('Sanjida123', 'Sanjida Ahmed', '01771670944', 'banani,dhaka', 'N/A', 'Female', '', 6),
('Sufian123', 'Sufian Rahman', '01634550017', 'Farmgate,dhaka', 'N/A', 'Male', '220px-Euan_Sutherland_-_Chief_Executive,_The_Co-operative_Group.jpg', 8);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `tec_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tec_id`, `name`, `phone`, `address`, `mail`, `designation`, `image`, `status`) VALUES
('biplob1', 'Biplob', '178554', 'Housebuilding', 'biplob1@gmail.com', 'Assistant Teacher', '52819597_585529761929490_7706524883672367104_n.jpg', 1),
('gg', 'hh', '0175458745', 'uttara', 'gjjfuyf', 'guggyg', 'images (1).jpg', 0),
('salman1', 'Salman', '01751896630', 'Uttara', 'salman@gmail.com', 'Lecturer', 'la110-55-2009-100532-high-jpg.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`trnx_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`atten_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `salary_info`
--
ALTER TABLE `salary_info`
  ADD PRIMARY KEY (`salary_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stu_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`tec_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `trnx_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `atten_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `salary_info`
--
ALTER TABLE `salary_info`
  MODIFY `salary_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
